var issue = [
  { 'severity': 4, 'type': 50103, 'sid': '0', 'extra': 'response suggests arithmetic evaluation on server side (type 1)', 'fetched': true, 'code': 200, 'len': 3739, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 4, 'type': 50103, 'sid': '0', 'extra': 'response to \x27\x27\x27\x27\x22\x22\x22\x22 different than to \x27\x22\x27\x22\x27\x22\x27\x22', 'fetched': true, 'code': 200, 'len': 5429, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i1' },
  { 'severity': 3, 'type': 40304, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 5469, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': '[none]', 'dir': 'i2' },
  { 'severity': 3, 'type': 40101, 'sid': '0', 'extra': 'injected \x27\x3csfi...\x3e\x27 tag seen in HTML', 'fetched': true, 'code': 200, 'len': 5469, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i3' },
  { 'severity': 0, 'type': 10803, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 5449, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': '[none]', 'dir': 'i4' },
  { 'severity': 0, 'type': 10204, 'sid': '0', 'extra': 'X-XSS-Protection', 'fetched': true, 'code': 200, 'len': 5449, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i5' }
];
