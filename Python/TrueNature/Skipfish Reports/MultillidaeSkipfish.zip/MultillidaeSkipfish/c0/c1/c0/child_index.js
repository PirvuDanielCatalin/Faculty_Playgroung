var child = [
  { 'dupe': true, 'type': 32, 'name': 'LogHandler.php', 'dir': 'c0', 'linked': 1, 'url': 'http://localhost/app/classes/LogHandler.php', 'fetched': true, 'code': 404, 'len': 298, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'iso-8859-1', 'missing': true, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0xffdfffff },
  { 'dupe': true, 'type': 32, 'name': 'MySQLHandler.php', 'dir': 'c1', 'linked': 1, 'url': 'http://localhost/app/classes/MySQLHandler.php', 'fetched': true, 'code': 404, 'len': 300, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'iso-8859-1', 'missing': true, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0xffdfffff }
];
