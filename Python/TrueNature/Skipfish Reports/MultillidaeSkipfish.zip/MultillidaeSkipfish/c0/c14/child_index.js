var child = [
  { 'dupe': false, 'type': 64, 'name': 'level1HintIncludeFile=57', 'dir': 'c0', 'linked': 2, 'url': 'http://localhost/hints-page-wrapper.php?level1HintIncludeFile=57', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 }
];
