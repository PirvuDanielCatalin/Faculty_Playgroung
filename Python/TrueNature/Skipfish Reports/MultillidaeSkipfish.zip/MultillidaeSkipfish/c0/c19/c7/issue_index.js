var issue = [
  { 'severity': 3, 'type': 40201, 'sid': '0', 'extra': 'https://www.paypal.com/cgi-bin/webscr', 'fetched': true, 'code': 200, 'len': 40254, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 2, 'type': 30501, 'sid': '0', 'extra': 'https://www.paypalobjects.com/en_US/i/scr/pixel.gif', 'fetched': true, 'code': 200, 'len': 40254, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': '[none]', 'dir': 'i1' },
  { 'severity': 0, 'type': 10803, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 40254, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': '[none]', 'dir': 'i2' },
  { 'severity': 0, 'type': 10405, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 40254, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': '[none]', 'dir': 'i3' }
];
