var issue = [
  { 'severity': 4, 'type': 50103, 'sid': '0', 'extra': 'response suggests arithmetic evaluation on server side (type 2)', 'fetched': true, 'code': 302, 'len': 0, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 3, 'type': 40501, 'sid': '0', 'extra': 'responses for ./val and .../val look different', 'fetched': true, 'code': 200, 'len': 50924, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i1' },
  { 'severity': 3, 'type': 40304, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 52313, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': '[none]', 'dir': 'i2' },
  { 'severity': 3, 'type': 40201, 'sid': '0', 'extra': 'https://www.paypal.com/cgi-bin/webscr', 'fetched': true, 'code': 200, 'len': 44443, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': '[none]', 'dir': 'i3' },
  { 'severity': 3, 'type': 40101, 'sid': '0', 'extra': 'injected \x27\x3csfi...\x3e\x27 tag seen in HTML', 'fetched': true, 'code': 200, 'len': 52313, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i4' },
  { 'severity': 2, 'type': 30601, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 46122, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'ISO-8859-1', 'dir': 'i5' },
  { 'severity': 2, 'type': 30501, 'sid': '0', 'extra': 'https://www.paypalobjects.com/en_US/i/scr/pixel.gif', 'fetched': true, 'code': 200, 'len': 44443, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': '[none]', 'dir': 'i6' },
  { 'severity': 0, 'type': 10803, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 44443, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': '[none]', 'dir': 'i7' },
  { 'severity': 0, 'type': 10602, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 56467, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': '[none]', 'dir': 'i8' }
];
