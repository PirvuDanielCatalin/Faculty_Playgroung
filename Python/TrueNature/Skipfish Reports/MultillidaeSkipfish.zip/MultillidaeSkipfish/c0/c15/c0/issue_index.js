var issue = [
  { 'severity': 2, 'type': 30601, 'sid': '0', 'extra': '', 'fetched': true, 'code': 302, 'len': 2821, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'ISO-8859-1', 'dir': 'i0' }
];
