var child = [
  { 'dupe': false, 'type': 4, 'name': 'testoutput', 'dir': 'c0', 'linked': 2, 'url': 'http://localhost/webservices/test/testoutput/', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 },
  { 'dupe': false, 'type': 64, 'name': 'C=N', 'dir': 'c1', 'linked': 2, 'url': 'http://localhost/webservices/test/?C=N;O=D', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 },
  { 'dupe': false, 'type': 64, 'name': 'O=D', 'dir': 'c2', 'linked': 2, 'url': 'http://localhost/webservices/test/?C=N;O=D', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 }
];
