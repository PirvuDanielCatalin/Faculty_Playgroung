var child = [
  { 'dupe': false, 'type': 32, 'name': 'ws-user-account.php', 'dir': 'c0', 'linked': 2, 'url': 'http://localhost/webservices/rest/ws-user-account.php', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 }
];
