var child = [
  { 'dupe': false, 'type': 32, 'name': 'ws-hello-world.php', 'dir': 'c0', 'linked': 2, 'url': 'http://localhost/webservices/soap/ws-hello-world.php', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 },
  { 'dupe': false, 'type': 32, 'name': 'ws-lookup-dns-record.php', 'dir': 'c1', 'linked': 2, 'url': 'http://localhost/webservices/soap/ws-lookup-dns-record.php', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 },
  { 'dupe': false, 'type': 32, 'name': 'ws-user-account.php', 'dir': 'c2', 'linked': 2, 'url': 'http://localhost/webservices/soap/ws-user-account.php', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 }
];
